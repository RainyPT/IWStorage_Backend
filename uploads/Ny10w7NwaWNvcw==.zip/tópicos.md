﻿tópicos - Modelos conceptual, lógico e físico de uma base de dados 

Os modelos de dados irá facilitar a interação entre os projetistas, programadores e os utilizadores finais. Um modelo bem projetado vai promover uma compreensão da organização mais favorável, ou seja, estes modelos de dados vão ser uma ferramentas de comunicação. 

Os modelos de dados visa pelo menos em três pontos: 

- Visão dos dados em vez da visão das aplicações; 
- Eliminação das redundâncias; 
- Partilha de dados pelas aplicações. 

Para construir um modelo de dados é preciso Identificar, Analisar e Registar a política da organização sobre os dados. 

A definição deste modelo de dados é feita a três níveis: 

- Conceptual - Representação exata da realidade sem qualquer restrição imposta pelo modelo informático. 
- Lógico - Adaptar o modelo conceptual para um modelo de dados específicos, mas independente de qualquer SGBD. 
- Físico - Adaptação do modelo lógico às características do sistema informático. 

A técnicas de modelação divide-se em dois grupos: 

- Do particular para o geral (usada mais para pequenos projetos) 
- Do geral para o particular (usado para grandes projetos) 

SQL Avançado: Views: 

- Representam os dados que estão contidos numa tabela 
- Filtram o conteúdo da tabela 
- Existem dois tipos de views: 
- SELECT 
- UPDATE 

Trigger: 

- Para criar um trigger é usado a seguinte sintaxe: 

(CREATE TRIGGER [NOME DO TRIGGER] 

` `ON [NOME DA TABELA] 

` `[FOR/AFTER/INSTEAD OF] [INSERT/UPDATE/DELETE]  AS) 

- Funções dos triggers: 
- Manter a consistência 
- Facilita a criação de um software 
- Propaga as alterações 
- Corre automaticamente quando ocorre um evento 

Procedimento Armazenado: 

É uma coleção de comandos SQL em que encapsulam tarefas repetidas (como IF e ELSE, WHILE, LOOP, REPEAT e CASE) e tem como função principal em aceitar parâmetros de entrada e retorna um valor de estado 

Estes procedimentos são carecterizados como: 

- System Defined Stored Procedure 
- Extended Procedure 
- User Defined Stored Procedure 
- CLR Stored Procedure 

System Defined Stored Procedure: 

- Este procedimento já está definido no SQL Server e começa usando o prefixo sp\_ 

Extended Procedure: 

- São implementadas como DLL e são executadas fora do SQL Server. É identificada com o prefixo xp\_ 

User Defined Stored Procedure: 

- São criadas pelas próprias ações do utilizador. Pode ser criada numa base de dados qualquer à exceção da BD Resource ou numa base de dados definida pelo utilizador 

CLR Stored Procedure: 

- Este procedimento é baseado na Common Language Runtime na plataforma .NET e permite ser programado nas linguagens .NET 
- Pode invocar as seguintes instruções: 
- DDL (Linguagem de Definição de Dados) 
- DML (Linguagem de Manipulação de Dados) 
